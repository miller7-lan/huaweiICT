"""Record source-checked AI findings without manufacturing human attestations."""

import json
from datetime import datetime, timezone
from pathlib import Path

from gov_mcp.knowledge import KnowledgeStore, fingerprint
from gov_mcp.knowledge_quality import publication_policy


ROOT = Path(__file__).resolve().parents[1]

WEB_SOURCES = {
    "ERQI-NEARBY-2026-WEB": {"url": "https://zzga.zhengzhou.gov.cn/jwzx/9863401.jhtml", "kind": "official_local_service_information", "acquisition": "live_browser_read_only_normal_collector_robots_denied", "locator": "2026-01-23；正文第2段就近办覆盖说明", "unresolved": "二七区警务室服务包含身份证补换领；报道案例是丢失补领，未提供到期换领完整材料和全区地址表。正常采集已暂停，没有本地原件归档或恢复访问的声明"},
    "HN-MEASURES-2024-JY-WEB": {"url": "https://gaj.jiyuan.gov.cn/14190/15132/15148/t961601.html", "kind": "official_police_policy_explanation", "acquisition": "first_measure_normally_archived_other_sections_web_read_only", "archived_source_id": "HN-MEASURES-2024-JY", "locator": "第一项及其解读；第三项条件与适用情形；页面2024-10-17、来源河南省公安厅", "unresolved": "第一项25自然日已正常归档；当前效力和后续调整未核定。网办第三项限丢失补领/损坏换领，不能套用普通到期换领；自费邮寄说明未核定到二七具体渠道"},
    "NDRC-EXEMPT-2004-WEB": {"url": "https://www.ndrc.gov.cn/xxgk/zcfb/qt/200905/t20090512_967638.html", "kind": "official_administrative_norm", "acquisition": "live_browser_read_only_normal_collector_robots_denied", "locator": "财综〔2004〕8号第一、二、五项，署名2004-02-06", "unresolved": "历史文本区分免收和减半及证明条件；现行类别、后续政策和本地证明方式仍需核定。自动采集已暂停，未取得本地原件；URL的200905目录不是生效日"},
    "NDRC-FEE-2003-WEB": {"url": "https://zfxxgk.ndrc.gov.cn/web/iteminfo.jsp?id=19901", "kind": "publishing_ministry_normative_catalog", "acquisition": "read_only_web_text", "locator": "发改价格〔2003〕2322号第一、四、五项；2003-12-30印发", "unresolved": "发布者规范性文件页面列20/40/10元及2004-01-01执行；不能仅凭网页仍展示证明全部内容当前有效。原精确PDF采集来源仍暂停，2017拟废止目录不是最终废止决定；首次申领及减免另查后续规定"},
    "ERQI-GUIDE-WEB": {"url": "https://eq.jiceng.zhengzhou.gov.cn/004008002/3394639.jhtml", "kind": "official_service_guide", "acquisition": "read_only_web_preview", "locator": "办理条件、收费、时限和材料1至4项", "unresolved": "页面未明确更新日；材料关系与省级分支有差异；采集器当前暂停"},
    "ERQI-RENHE-WEB": {"url": "https://eq.jiceng.zhengzhou.gov.cn/004008002/6045830.jhtml", "kind": "official_local_service_guide", "acquisition": "read_only_web_preview", "locator": "人和路派出所窗口信息及收费/时限", "unresolved": "仅人和路窗口；页面未明确更新日；不能扩展成全区地点表"},
    "HN-NORM-PDF-WEB": {"url": "https://www.xuchang.gov.cn/EpointWebBuilder/frame/ewebeditor/uploadfile/%E6%B2%B3%E5%8D%97%E7%9C%81%E5%85%AC%E5%AE%89%E5%8E%85%E5%85%B3%E4%BA%8E%E5%8D%B0%E5%8F%91%E3%80%8A%E6%B2%B3%E5%8D%97%E7%9C%81%E5%85%AC%E5%AE%89%E6%9C%BA%E5%85%B3%E6%88%B7%E5%8F%A3%E5%B1%85%E6%B0%91%E8%BA%AB%E4%BB%BD%E8%AF%81%E7%AE%A1%E7%90%86%E5%B7%A5%E4%BD%9C%E8%A7%84%E8%8C%83%EF%BC%88%E8%AF%95%E8%A1%8C%EF%BC%89%E3%80%8B%E7%9A%84%E9%80%9A%E7%9F%A5.pdf", "kind": "official_normative_pdf", "acquisition": "web_text_preview_only", "locator": "PDF第1、3、45、46、64页；第7、157、159、161、236条", "unresolved": "该64页PDF仍仅有文本预览，截图超时、本地原件未取得。另已取得省厅发布HTML的14个完整条款，见归档HN-NORM-PUBLISHER；不能将HTML称作已下载的盖章PDF"},
    "HN-UPDATE-GUSHI-WEB": {"url": "https://www.gushi.gov.cn/2025/07-10/760173.html", "kind": "official_republished_service_update", "acquisition": "normal_guarded_local_archive_now_available", "archived_source_id": "HN-UPDATE-GS-01", "locator": "正文段落3；页面2025-07-10、来源河南政府网", "unresolved": "已正常归档并监测一段期限调整事实；图片未取得。尚未定位原始省厅调整文件及完整生效范围，不能把转载日期当生效日"},
    "HN-UPDATE-ANYANG-WEB": {"url": "https://www.ayx.gov.cn/2025/07-22/3533496.html", "kind": "official_police_service_explanation", "acquisition": "read_only_web_preview", "locator": "2025-07-22、安阳县公安温馨提醒、我省便民举措", "unresolved": "同样提到我省放宽至6个月；本县自助、网办、上班时段不能套用二七区"},
    "USE-CENTRAL-WEB": {"url": "https://app.www.gov.cn/govdata/gov/201608/11/386933/article.html", "kind": "official_republication", "acquisition": "read_only_web_preview", "locator": "页面2016-08-11、正文署名2016-07-15、末尾实施句", "unresolved": "能佐证日期层次不同，尚不足裁定公告最初发布日"},
    "NPC-LAW-LEAD": {"url": "https://wb.flk.npc.gov.cn/flfg/PDF/481dce0469334593bc9050435f09d60e.pdf", "kind": "official_law_gazette", "acquisition": "search_preview_lead_robots_tls_failed", "locator": "全国人大常委会公报2011年第7号、修正决定及重新公布文本", "unresolved": "已定位2011修正原始公报线索；正常robots请求因证书过期失败，未请求PDF或关闭TLS校验；另有官方转载归档，但原始公报及完整现行沿革核验仍待完成"},
    "HN-XICHUAN-LEAD": {"url": "https://www.xichuan.gov.cn/ifile/20251229/1766973939411PxhOsju6.pdf", "kind": "official_normative_pdf_lead", "acquisition": "access_denied_403", "locator": None, "unresolved": "新独立官方原件线索也返回403；没有下载、换身份或绕过"},
}

# References below are authored from source texts and local runtime controls,
# never from the tested agent's generated answers. They remain AI drafts.
ANSWERS = [
    ("conditional_answer", "省级第159条的换领分支写交验居民身份证；国家第78条将申领、换领、补领并列后写交验户口簿，区级指南也列户口簿。需保留这些表述及共享确认条件，继续核定当前本地关系；不把两证合成无条件必交，也不保证只带旧证受理。", ["ERQI-GUIDE-WEB", "HN-NORM-PDF-WEB"], ["ID-GUIDE-01", "MPS-NORM-01"], ["国家、省级及区级材料关系未决"]),
    ("stop", "不能断言户口簿一律必带或免带。国家第78条、河南第159条和区级列表应分别核对，且共享确认免纸质存在前提；当前二七区执行关系尚未解决。", ["ERQI-GUIDE-WEB", "HN-NORM-PDF-WEB"], ["ID-GUIDE-01", "MPS-NORM-01"], ["必交和条件免交关系未决"]),
    ("conditional_answer", "应区分申请时交验旧证与领取新证时交回旧证；后者有居民身份证法第11条的明确依据。不能将交验直接解释为申请当天一律收走。", [], ["ID-LAW-01", "MPS-NORM-01"], ["具体窗口留存环节待确认"]),
    ("conditional_answer", "2021国家规范及2022省级规范写到期前三个月；已归档的固始政府2025-07-10转载河南政府网说明，明确记录河南省公安厅将到期换领期限从3个月放宽到6个月。可以说明这项更新及来源日期，但尚未取得调整原文件和完整起止日期，不将旧三个月写作唯一现行上限，也不作二七区当前受理保证。", ["HN-NORM-PDF-WEB", "HN-UPDATE-ANYANG-WEB"], ["MPS-NORM-01", "HN-UPDATE-GS-01"], ["省厅调整原文件、起止日期和二七区当前执行关系未核定"]),
    ("conditional_answer", "规范支持办理时采集人像。二七区是否允许自带照片、选哪些拍摄渠道，目前材料不足，不能移用其他城市规则。", [], ["MPS-NORM-01"], ["本地拍摄选项未核定"]),
    ("stop", "没有取得要求本分支提交照片回执或电子照片文件的二七区依据，不添加此项必交材料。", ["ERQI-GUIDE-WEB"], ["ID-GUIDE-01"], ["本地照片细则缺失；未列出不等于证明永远不需要"]),
    ("conditional_answer", "2011修正法律第3条规定申请领取、换领、补领居民身份证应登记指纹信息；已归档的省厅规范第159条涉及办理时采集。具体采集困难、复用或例外不能自行裁决。", ["HN-NORM-PDF-WEB"], ["ID-AMENDMENT-JT-LEAD", "MPS-NORM-01"], ["特殊情形未纳入试点；转载页日期冲突，不代替完整现行沿革核定"]),
    ("stop", "现有证据没有给出本地各项材料的完整原件、复印件和份数表，不能统一编成复印件一份。", ["ERQI-GUIDE-WEB"], ["ID-GUIDE-01"], ["形式及份数缺失"]),
    ("stop", "不能把补领分支可交验证件之一直接当作换领时替代户口簿的规则。应核对共享调用和换领分支规定。", ["HN-NORM-PDF-WEB"], ["MPS-NORM-01"], ["换领替代关系未决"]),
    ("conditional_answer", "2021省厅措施写换补领省内通办；郑州公安2026-01-23报道又说明二七区警务室就近办服务包含身份证补换领，说明不能只凭旧指南断言必须回户籍派出所。但报道案例是丢失补领，未给到期换领完整材料、全区办理地址和时段；人和路指南也只是单点线索，不能承诺任一警务室今天均受理本分支。", ["ERQI-GUIDE-WEB", "ERQI-RENHE-WEB", "ERQI-NEARBY-2026-WEB"], ["HN-MEASURES-2021-PDF"], ["最新到期换领窗口清单、受理条件及预约方式未完整核定；2026报道仅网页核查，采集被拒；旧PDF保留OCR和视觉检查记录"]),
    ("stop", "尚无本分支统一强制预约及完整线上申请入口的直接依据。2024省级措施解读的网上办条款明确限丢失补领、损坏换领；2026二七区就近办报道也不是到期换领网办申请入口。不得把咨询入口、公众号或补领网办拼成到期换领入口。", ["ERQI-GUIDE-WEB", "HN-UPDATE-ANYANG-WEB", "HN-MEASURES-2024-JY-WEB", "ERQI-NEARBY-2026-WEB"], [], ["本地预约/到期换领申请入口未核定"]),
    ("conditional_answer", "二七区指南和发改价格〔2003〕2322号发布者页面均列换领20元/证；法律本身不列该金额。法律第21条区分免收和可减收，财综〔2004〕8号历史文本另分免收、减半及相应证明条件，不能简化为所有困难居民都免收。可以说明这些原文层次，但当前减免类别、证明方式和后续收费政策尚未完整核验；不套用补领40元或把快递费并成工本费，也不保证每个人均交20元。", ["ERQI-GUIDE-WEB", "ERQI-RENHE-WEB", "NDRC-FEE-2003-WEB", "NDRC-EXEMPT-2004-WEB"], ["ID-AMENDMENT-JT-LEAD"], ["国家收费文件后续沿革及当前减免证明方式未完整核验；发改委采集器暂停，网页核查不是本地原件；2017拟废止目录不能作为已废止依据"]),
    ("conditional_answer", "应区分法律60日、国家规范45日、2021省厅措施30自然日、2024省级措施25自然日和区级指南15个工作日。新归档的济源公安转载第一项明确将受理之日起到领证之日缩短至25个自然日，页面2024-10-17、来源河南省公安厅；它是2021措施之后的重要更新，不能继续只用30日回答。自然日与工作日不直接换算，转载日也不是政策生效日；后续调整与二七区当前承诺仍需核定，不挑一个最短时限作结果保证。", ["ERQI-GUIDE-WEB", "HN-MEASURES-2024-JY-WEB"], ["ID-LAW-01", "MPS-NORM-01", "HN-MEASURES-2021-PDF", "HN-MEASURES-2024-JY"], ["2024措施原发布文件、生效日期、后续关系及二七区当前承诺仍需核定；2021扫描件保留OCR原文和视觉核查"]),
    ("conditional_answer", "国家规范第八十ー条写委托亲属代领，省级第164条写委托他人代领，两份原文的范围措辞应分别保留，当前适用关系待核定；不能将两者概括成同一亲属限制，也不能保证任何他人一定可代领。本人领取的核验/指纹/签名与代领环节分别记录，代领不等于代理申请。2024官方转载解读另有自选自费邮寄说明，但尚未核定二七区当前入口、费用及收件核验，不作办理保证或套用外市快递价格。", ["HN-MEASURES-2024-JY-WEB"], ["MPS-NORM-01"], ["国家亲属/省级他人代领措辞的当前适用关系未核定；本地邮寄入口、费用及核验条件未定；邮寄说明为网页核查，未选入本地25日归档片段"]),
    ("conditional_answer", "规范支持核验签名后发领取凭证；本地进度查询入口尚未核定。问答端不代收完整身份证号码，不代查个人办理记录。", [], ["MPS-NORM-01"], ["本地查询地址缺失"]),
    ("stop", "临时居民身份证属于另一事项；可提示存在该事项，但停止在本试点拼出其完整材料和流程。", [], ["ID-LAW-01"], []),
    ("stop", "旧证是否可用于某一业务须看证件有效状态、换领阶段及有关使用规定。现有证据不足支持换领期间旧证一律有效或一律立即失效。", [], ["ID-LAW-01", "MPS-NORM-01"], ["具体使用情境和旧证状态未明确"]),
    ("conditional_answer", "办理规范涉及身份材料、人像和指纹核验；使用管理公告涉及必要核查与个人信息保护。咨询问题不需要发送完整身份证号码或证件照片。", [], ["MPS-NORM-01", "MPS-USE-01"], []),
    ("stop", "指出具体条款及适用分支差异，保留双方证据；未解决现行适用和材料关系前，不自动选一份拼成确定清单。", ["ERQI-GUIDE-WEB", "HN-NORM-PDF-WEB"], ["MPS-NORM-01"], ["具体冲突需逐项核对"]),
    ("stop", "签署日、网页发布日、转载日和条文明示生效日分别保存。国家规范有明确实施条款；公告日期仍有待核项。不能从URL年份或抓取日推导生效日。", ["USE-CENTRAL-WEB"], ["MPS-NORM-01", "MPS-USE-01"], ["公告原始发布日未定"]),
    ("conditional_answer", "以咨询日期匹配已生效且未失效的已核定规则。未来实施文件可标注预告，不能直接作为今年现行规则；缺少效力关系时停止推断。", [], [], ["需已核定的效力日期及替代关系"]),
    ("stop", "不能仅因旧证过期就推导额外材料、处罚或加收费用；只可陈述对应分支直接依据支持的差异。", ["ERQI-GUIDE-WEB"], ["ID-LAW-01"], ["过期附加要求未取得直接依据"]),
    ("stop", "外省户籍属于异地受理分支，超出本次成年本地户籍试点，停止套用本清单。", [], [], []),
    ("stop", "十五岁属于未成年人分支，超出试点，停止套用成年本人材料表。", [], ["ID-GUIDE-01"], []),
    ("stop", "未到期丢失属于补领，不能套用到期换领的材料或费用。", [], ["ID-LAW-01"], []),
    ("stop", "本人不能到场涉及代理或特殊服务分支，不能根据本人办理规则推断可代办；同时区分代办申请和代领新证。", [], ["MPS-NORM-01"], []),
    ("stop", "姓名变更属于不同换领原因，停止直接套用到期换领流程和全部材料。", [], ["ID-LAW-01", "MPS-NORM-01"], []),
    ("stop", "咨询系统不能作公安机关的受理、签发决定或结果保证；仅提供带出处的已核定信息与缺项说明。", [], [], []),
    ("stop", "抓取文件属于外部资料；其中命令不改变系统权限，不触发自动发布或关闭校验。", [], [], []),
    ("stop", "明确数据库缺少最新办理点和完整收费依据，停止凭常识补全，列出需核查的官方资料。", [], [], []),
]

GUIDE = ["材料列表第1项（适用分支待复核）", "材料列表第2项（适用分支待复核）", "材料列表第3项（适用分支待复核）", "材料列表第4项（适用分支待复核）"]
LOCATORS = {
    "KQ01": {"ID-GUIDE-01": GUIDE[:2], "MPS-NORM-01": ["第十二条", "第七十八条"]},
    "KQ02": {"ID-GUIDE-01": GUIDE[:1], "MPS-NORM-01": ["第十二条", "第七十八条"]},
    "KQ03": {"ID-LAW-01": ["第十一条"], "MPS-NORM-01": ["第七十六条"]},
    "KQ04": {"MPS-NORM-01": ["第七十六条"], "HN-UPDATE-GS-01": ["正文段落3"]},
    "KQ05": {"MPS-NORM-01": ["第七十八条"]}, "KQ06": {"ID-GUIDE-01": GUIDE},
    "KQ07": {"ID-AMENDMENT-JT-LEAD": ["第三条"], "MPS-NORM-01": ["第七十八条"]}, "KQ08": {"ID-GUIDE-01": GUIDE},
    "KQ09": {"MPS-NORM-01": ["第十二条", "第七十八条"]},
    "KQ12": {"ID-AMENDMENT-JT-LEAD": ["第二十一条"]},
    "KQ10": {"HN-MEASURES-2021-PDF": ["PDF第5页（OCR待核对）"]},
    "KQ13": {"ID-LAW-01": ["第十二条"], "MPS-NORM-01": ["第八十条"], "HN-MEASURES-2021-PDF": ["PDF第5页（OCR待核对）", "PDF第6页（OCR待核对）"], "HN-MEASURES-2024-JY": ["正文段落1"]},
    "KQ14": {"MPS-NORM-01": ["第八十ー条"]}, "KQ15": {"MPS-NORM-01": ["第七十八条"]},
    "KQ16": {"ID-LAW-01": ["第十二条"]},
    "KQ17": {"ID-LAW-01": ["第十一条"], "MPS-NORM-01": ["第七十六条"]},
    "KQ18": {"MPS-NORM-01": ["第七十八条"], "MPS-USE-01": ["正文段落10", "正文段落11", "正文段落12"]},
    "KQ19": {"MPS-NORM-01": ["第十二条", "第七十八条"]},
    "KQ20": {"MPS-NORM-01": ["第九十七条"], "MPS-USE-01": ["正文段落15", "正文段落16"]},
    "KQ22": {"ID-LAW-01": ["第十一条"]}, "KQ24": {"ID-GUIDE-01": GUIDE[2:3]},
    "KQ25": {"ID-LAW-01": ["第十一条"]}, "KQ26": {"MPS-NORM-01": ["第八十ー条"]},
    "KQ27": {"ID-LAW-01": ["第十一条"], "MPS-NORM-01": ["第七十六条"]},
}

# Replace indirect norm references with the newly acquired publisher clauses.
# These choices come from the source text, not the tested model's retrieval.
PUBLISHER_LOCATORS = {
    "KQ01": ["第七条", "第一百五十九条"], "KQ02": ["第七条", "第一百五十九条"],
    "KQ03": ["第一百六十一条"], "KQ04": ["第一百五十七条"], "KQ05": ["第一百五十九条"],
    "KQ07": ["第一百五十九条"], "KQ09": ["第七条", "第一百五十九条"],
    "KQ12": ["第二百三十四条"], "KQ13": ["第一百六十三条"], "KQ14": ["第一百六十四条"],
    "KQ15": ["第一百五十九条"], "KQ16": ["第一百六十五条"], "KQ17": ["第一百六十一条"],
    "KQ18": ["第一百五十九条"], "KQ19": ["第七条", "第九条", "第一百五十九条"],
    "KQ20": ["第二百三十六条"], "KQ22": ["第一百五十九条"],
    "KQ25": ["第一百五十九条"], "KQ26": ["第一百六十四条"], "KQ27": ["第一百五十七条"],
}
REPLACE_NATIONAL_LOCATORS = {"KQ03", "KQ05", "KQ07", "KQ15", "KQ17", "KQ18", "KQ27"}


def main():
    draft = json.loads((ROOT / "evaluation/knowledge/pilot-business-questions.json").read_text(encoding="utf-8"))
    store = KnowledgeStore(ROOT / ".runtime/knowledge-update", read_only=True)
    wanted_sources = {source for _, _, _, sources, _ in ANSWERS for source in sources} | {"HN-NORM-PUBLISHER"}
    with store.db() as db:
        local = {}
        for row in db.execute("SELECT d.site_id,d.url,r.id AS revision,r.sha256 FROM documents d JOIN revisions r ON r.document_id=d.id WHERE r.rowid IN (SELECT MAX(rowid) FROM revisions GROUP BY document_id)"):
            if row["site_id"] not in wanted_sources:
                continue
            if row["site_id"] in local:
                raise ValueError("Reference source has multiple documents; bind a document explicitly instead of overwriting it")
            local[row["site_id"]] = dict(row)
        for source in local.values():
            source["locators"] = [row[0] for row in db.execute("SELECT locator FROM chunks WHERE revision_id=? ORDER BY ordinal", (source["revision"],))]
    assert len(draft["cases"]) == len(ANSWERS) == 30
    cases = []
    for original, (behavior, answer, web_ids, local_ids, unresolved) in zip(draft["cases"], ANSWERS):
        locators_by_source = dict(LOCATORS.get(original["id"], {}))
        assert set(locators_by_source) == set(local_ids)
        web_ids = list(web_ids)
        if original["id"] in PUBLISHER_LOCATORS:
            locators_by_source["HN-NORM-PUBLISHER"] = PUBLISHER_LOCATORS[original["id"]]
            if original["id"] in REPLACE_NATIONAL_LOCATORS:
                locators_by_source.pop("MPS-NORM-01", None)
            if original["id"] == "KQ19":
                locators_by_source["ID-GUIDE-01"] = GUIDE[:2]
            web_ids = [key for key in web_ids if key != "HN-NORM-PDF-WEB"]
        local_ids = list(locators_by_source)
        assert all(key in WEB_SOURCES for key in web_ids) and all(key in local for key in local_ids)
        references = []
        for source_id, locators in locators_by_source.items():
            assert set(locators) <= set(local[source_id]["locators"])
            references.extend({"revision": local[source_id]["revision"], "locator": locator} for locator in locators)
        cases.append({"id": original["id"], "question": original["question"], "category": original["category"],
                      "expected_behavior": behavior, "ai_reference_answer": answer,
                      "web_evidence_ids": web_ids, "archived_evidence_ids": local_ids, "archived_evidence": references,
                      "unresolved": unresolved, "human_review_status": "not_performed",
                      "tested_agent_output_used_as_reference": False})
    report = {"schema_version": 1, "dataset_id": "erqi-adult-local-id-renewal-ai-source-check-v1",
              "status": "ai_source_checked_draft", "author_kind": "ai", "reviewer": "Codex AI",
              "captured_at": datetime.now(timezone.utc).isoformat(), "scope": draft["scope"],
              "purpose": "User-authorized takeover of source analysis, materials analysis and reference-answer drafting; not an independent human acceptance report",
              "human_review_completed": False, "ready_for_business_publication": False,
              "publication_policy_changed_by_this_preparation": False,
              "publication_policy_sha256": fingerprint(publication_policy(store)),
              "source_fact_assessment_sha256": fingerprint((ROOT / "evaluation/knowledge/source-fact-assessments.json").read_bytes()) if (ROOT / "evaluation/knowledge/source-fact-assessments.json").exists() else None,
              "web_sources": WEB_SOURCES, "archived_sources": local,
              "cases": cases}
    report["content_sha256"] = fingerprint(report)
    (ROOT / "evaluation/knowledge/pilot-ai-reference-answers.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"cases": len(cases), "reference_entries": len(WEB_SOURCES)+len(local),
        "unique_source_urls": len({source["url"] for source in list(WEB_SOURCES.values())+list(local.values())}),
        "status": report["status"], "human_attestations_created": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
