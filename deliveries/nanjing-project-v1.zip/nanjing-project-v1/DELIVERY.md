# 南京事项项目交付与复现

本包是已提交公开项目的完整源码、配置、测试、官方原件和证据快照，保留原Git路径；仅去掉历史重复分发包及其源码镜像，不删项目运行资料。`delivery-manifest.json` 记录原提交、每个文件的字节/哈希和明确排除清单。另附同内容ZIP和解压目录。账户、运行库、令牌、模型权重及本机环境均不打包。

## 新环境复现

需要Python 3.11及以上。Windows OCR复现另需已有Windows语言识别组件；本轮包内已保存真实识别返回，不自动安装组件。联网安装固定依赖后执行：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock -r requirements-knowledge.lock
.\.venv\Scripts\python.exe scripts/verify_matter_update_inputs.py
.\.venv\Scripts\python.exe scripts/reproduce_matter_project.py --runtime .runtime/clean-reproduction
```

复现器核对项目模块确实从解压目录导入；新建随机私有工程账户和两个版本，真实启动仅监听127.0.0.1的HTTP服务，验证四来源种子停止、演化后四条替代证明支持一个结论、旧任务固定、群众/工作人员交接、其他工作人员越权拒绝及当前来源暂停对历史任务生效。最后只关闭自己启动的服务，隔离资料库保留暂停状态与回执。重复运行需新空目录，不覆盖历史。

这是已归档来源上的开发场景工程复现。不会请求政府官网或模型，也不刷新原抓取日。抓取超过24小时后来源新鲜度应停止，不能改日期或延长窗口伪装最新适用；须按更新流程实际重新观察、复核差异再另建活动。

## Nexent与本地Qwen

完整公开源码包含Nexent接入、五工具MCP、主控/两个子Agent的准备和登记脚本以及Skills。机器专属模型ID、AgentID、账户和令牌须在目标环境按真实登记生成，不复制本机私有文件。已有模型名称为 `gov-qwen3-8b:ctx8192-v1` 和 `gov-qwen3-4b:ctx8192-v1`；不会自动下载权重或自动启动模型。

先按仓库本机部署说明准备Nexent与Ollama和私有角色映射，使用 `prepare_matter_web.py --auth nexent --role-map 私有映射.json --pack data/real-matter-closure/nanjing/update-snapshots-v1/registered-four` 建新活动。原生步骤及明确预算见 [南京事项本地原生编排](docs/南京事项本地原生编排.md)。`prepare/provision`只准备资产，`verify_matter_native.py --live` 才执行模型；不得复制已关闭活动、清空次数或把准备成功算推理成功。

当前交付不包含重新部署的Nexent容器或已在新机器执行的原生模型验收。新Python环境的本地HTTP复现与现有Nexent真实账户的19项联调分别记录，不混为“新机器全平台通过”。旧原生失败报告保留；真实最新结果以相应证据为准。

## 业务与评测状态

南京16条规则、本体关系、OCR和问答均保持候选；正式业务发布关闭。OCR第4页混有草案说明，完整识别和错字保留，尚未把OCR页提升为法条证据。设计、来源、版本和原生编排文档位于 `docs/`，实际运行报告位于 `evidence/real-matter-closure/`。

独立评测须由未参与开发的真实评测人先冻结案例组及参考依据。公开开发案例、替代证据路径、合成夹具和已有回执不能改名当留出集。评测协议及待填提交见对应评测文档；包的完整性和工程复现不代表人工批准或独立业务准确率。
